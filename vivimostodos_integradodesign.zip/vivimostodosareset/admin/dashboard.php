<?php
require_once 'C:\xampp\htdocs\vivimostodos/config/session.php';
require_once 'C:\xampp\htdocs\vivimostodos/config/functions.php';
requireRole(['ADMIN']);

$db = getDB();
$pageTitle = 'Dashboard';

// Stats
$totalUsuarios      = $db->query("SELECT COUNT(*) FROM usuarios WHERE estado='ACTIVO'")->fetchColumn();
$totalReservas      = $db->query("SELECT COUNT(*) FROM reservas")->fetchColumn();
$reservasPendientes = $db->query("SELECT COUNT(*) FROM reservas WHERE estado='PENDIENTE'")->fetchColumn();
$reservasAprobadas  = $db->query("SELECT COUNT(*) FROM reservas WHERE estado='APROBADA'")->fetchColumn();
$pagosPendientes    = $db->query("SELECT COUNT(*) FROM pagos WHERE estado='PENDIENTE'")->fetchColumn();
$ingresosMes        = $db->query("SELECT COALESCE(SUM(monto),0) FROM pagos WHERE estado='VALIDADO' AND MONTH(fecha_pago)=MONTH(NOW())")->fetchColumn();

// Last 5 reservas
$ultimasReservas = $db->query(
    "SELECT r.id_reserva, r.fecha_evento, r.estado, r.fecha_solicitud,
            u.nombre, u.apellido
     FROM reservas r
     JOIN usuarios u ON r.id_usuario = u.id_usuario
     ORDER BY r.fecha_solicitud DESC LIMIT 5"
)->fetchAll();

include 'C:/xampp/htdocs/vivimostodos/includes/header.php';
include 'C:/xampp/htdocs/vivimostodos/includes/sidebar.php';
?>

<!-- Welcome bar -->
<div class="d-flex align-items-center justify-content-between mb-4 animate-in">
    <div>
        <div class="section-title">Panel de Administración</div>
        <div class="section-subtitle">¡Hola! Aquí tienes el resumen de tu comunidad hoy 🏠</div>
    </div>
    <span style="font-size:0.78rem;color:var(--text-muted);font-family:var(--font-mono)"><?= date('l, d \d\e F Y') ?></span>
</div>

<!-- STAT CARDS -->
<div class="row g-3 mb-4">
    <div class="col-sm-6 col-xl-3 animate-in delay-1">
        <div class="stat-card">
            <div class="stat-icon blue">👥</div>
            <div>
                <div class="stat-label">Residentes activos</div>
                <div class="stat-value"><?= $totalUsuarios ?></div>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-xl-3 animate-in delay-2">
        <div class="stat-card">
            <div class="stat-icon green">📅</div>
            <div>
                <div class="stat-label">Total reservas</div>
                <div class="stat-value"><?= $totalReservas ?></div>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-xl-3 animate-in delay-3">
        <div class="stat-card">
            <div class="stat-icon yellow">⏳</div>
            <div>
                <div class="stat-label">Pendientes</div>
                <div class="stat-value"><?= $reservasPendientes ?></div>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-xl-3 animate-in delay-4">
        <div class="stat-card">
            <div class="stat-icon orange">💰</div>
            <div>
                <div class="stat-label">Ingresos este mes</div>
                <div class="stat-value" style="font-size:1.3rem"><?= formatMoneda((float)$ingresosMes) ?></div>
            </div>
        </div>
    </div>
</div>

<!-- CHARTS + TABLE -->
<div class="row g-3 mb-4">
    <!-- Chart Donut -->
    <div class="col-lg-5 animate-in delay-2">
        <div class="card h-100">
            <div class="card-header">
                <h5>📊 Reservas por Estado</h5>
            </div>
            <div class="card-body d-flex align-items-center justify-content-center">
                <canvas id="chartEstados" style="max-height:260px"></canvas>
            </div>
        </div>
    </div>
    <!-- Chart Bar -->
    <div class="col-lg-7 animate-in delay-3">
        <div class="card h-100">
            <div class="card-header">
                <h5>📈 Reservas Últimos 6 Meses</h5>
            </div>
            <div class="card-body">
                <canvas id="chartMeses" style="max-height:260px"></canvas>
            </div>
        </div>
    </div>
</div>

<div class="row g-3">
    <!-- Últimas reservas -->
    <div class="col-lg-8 animate-in delay-2">
        <div class="card">
            <div class="card-header">
                <h5>🕐 Últimas Reservas</h5>
                <a href="/vivimostodos/admin/reservas/index.php" class="btn btn-sm btn-outline-primary">Ver todas</a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table mb-0">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Residente</th>
                                <th>Fecha Evento</th>
                                <th>Estado</th>
                                <th>Acción</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($ultimasReservas as $r): ?>
                        <tr>
                            <td style="font-family:var(--font-mono);color:var(--text-muted);font-size:0.78rem">#<?= $r['id_reserva'] ?></td>
                            <td style="font-weight:500"><?= sanitize($r['nombre']) ?> <?= sanitize($r['apellido']) ?></td>
                            <td><?= formatFecha($r['fecha_evento']) ?></td>
                            <td>
                                <?php
                                $estadoLower = strtolower($r['estado']);
                                $badgeMap = [
                                    'pendiente' => ['⏳', 'badge-pendiente'],
                                    'aprobada'  => ['✅', 'badge-aprobada'],
                                    'rechazada' => ['❌', 'badge-rechazada'],
                                    'cancelada' => ['🚫', 'badge-cancelada'],
                                ];
                                [$icon, $cls] = $badgeMap[$estadoLower] ?? ['•', 'badge-cancelada'];
                                ?>
                                <span class="badge <?= $cls ?>"><?= $icon ?> <?= $r['estado'] ?></span>
                            </td>
                            <td>
                                <a href="/vivimostodos/admin/reservas/detalle.php?id=<?= $r['id_reserva'] ?>"
                                   class="btn btn-sm btn-outline-secondary" style="font-size:.75rem;padding:4px 12px">
                                   Ver
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Acciones rápidas -->
    <div class="col-lg-4 animate-in delay-3">
        <div class="card">
            <div class="card-header"><h5>⚡ Acciones Rápidas</h5></div>
            <div class="card-body d-flex flex-column gap-2">
                <a href="/vivimostodos/admin/usuarios/crear.php" class="quick-action">
                    <span>👤</span> Crear Usuario
                </a>
                <a href="/vivimostodos/admin/inventario/crear.php" class="quick-action">
                    <span>📦</span> Agregar Insumo
                </a>
                <a href="/vivimostodos/admin/pagos/index.php" class="quick-action">
                    <span>💳</span> Validar Pagos
                    <?php if ($pagosPendientes > 0): ?>
                    <span class="ms-auto badge badge-pendiente"><?= $pagosPendientes ?></span>
                    <?php endif; ?>
                </a>
                <a href="/vivimostodos/admin/reportes/semaforo.php" class="quick-action">
                    <span>🚦</span> Ver Semáforo
                </a>
                <a href="/vivimostodos/admin/notificaciones/enviar.php" class="quick-action">
                    <span>🔔</span> Enviar Notificación
                </a>
                <a href="/vivimostodos/admin/reportes/exportar_pdf.php" class="quick-action">
                    <span>📄</span> Exportar PDF
                </a>
            </div>
        </div>
    </div>
</div>

<?php
$extraJs = "<script>
(async () => {
    const res  = await fetch('/vivimostodos/api/graficos.php');
    const data = await res.json();

    // Colores de la paleta futurista
    const colors = ['#FFB347','#00E5A0','#FF5A5A','#A0A0C0'];
    const colorsBorder = ['rgba(255,179,71,0.3)','rgba(0,229,160,0.3)','rgba(255,90,90,0.3)','rgba(160,160,192,0.2)'];

    new Chart(document.getElementById('chartEstados'), {
        type: 'doughnut',
        data: {
            labels: data.estados.labels,
            datasets: [{
                data: data.estados.values,
                backgroundColor: colors.map(c => c + '26'),
                borderColor: colors,
                borderWidth: 2,
                hoverBackgroundColor: colors.map(c => c + '44'),
            }]
        },
        options: {
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        color: '#A0A0C0',
                        font: { family: 'Poppins', size: 11 },
                        padding: 16
                    }
                }
            },
            cutout: '68%'
        }
    });

    new Chart(document.getElementById('chartMeses'), {
        type: 'bar',
        data: {
            labels: data.meses.labels,
            datasets: [{
                label: 'Reservas',
                data: data.meses.values,
                backgroundColor: 'rgba(0,210,255,0.18)',
                borderColor: '#00D2FF',
                borderWidth: 1.5,
                borderRadius: 8,
                borderSkipped: false,
                hoverBackgroundColor: 'rgba(0,210,255,0.35)',
            }]
        },
        options: {
            plugins: { legend: { display: false } },
            scales: {
                x: {
                    ticks: { color: '#6B6B8A', font: { family: 'JetBrains Mono', size: 10 } },
                    grid: { color: 'rgba(255,255,255,0.04)' }
                },
                y: {
                    beginAtZero: true,
                    ticks: { stepSize: 1, color: '#6B6B8A', font: { family: 'JetBrains Mono', size: 10 } },
                    grid: { color: 'rgba(0,210,255,0.06)' }
                }
            }
        }
    });
})();
</script>";
include 'C:/xampp/htdocs/vivimostodos/includes/footer.php';
?>
