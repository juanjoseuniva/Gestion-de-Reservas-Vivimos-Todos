<?php
require_once 'config/session.php';
require_once 'config/database.php';
require_once 'config/functions.php';

if (session_status() === PHP_SESSION_NONE) session_start();

// Redirect if already logged in
if (isLoggedIn()) {
    $rol = currentRole();
    if ($rol === 'ADMIN') redirect('/vivimostodos/admin/dashboard.php');
    elseif ($rol === 'RESIDENTE') redirect('/vivimostodos/residente/mis_reservas.php');
    elseif ($rol === 'SUPERVISOR') redirect('/vivimostodos/supervisor/cronograma.php');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $correo   = trim($_POST['correo'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!$correo || !$password) {
        $error = 'Por favor completa todos los campos.';
    } else {
        $db   = getDB();
        $stmt = $db->prepare("SELECT * FROM usuarios WHERE correo = ? AND estado = 'ACTIVO' LIMIT 1");
        $stmt->execute([$correo]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['usuario'] = [
                'id_usuario' => $user['id_usuario'],
                'nombre'     => $user['nombre'],
                'apellido'   => $user['apellido'],
                'correo'     => $user['correo'],
                'rol'        => $user['rol'],
            ];
            session_regenerate_id(true);

            if ($user['rol'] === 'ADMIN') redirect('/vivimostodos/admin/dashboard.php');
            elseif ($user['rol'] === 'RESIDENTE') redirect('/vivimostodos/residente/mis_reservas.php');
            elseif ($user['rol'] === 'SUPERVISOR') redirect('/vivimostodos/supervisor/cronograma.php');
        } else {
            $error = 'Correo o contraseña incorrectos.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión — Vivimostodos</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="login-wrapper">
    <!-- Background patterns -->
    <div class="login-grid-bg"></div>

    <!-- Floating particles decoration -->
    <div style="position:absolute;inset:0;pointer-events:none;overflow:hidden">
        <div style="position:absolute;top:15%;left:8%;width:3px;height:3px;background:var(--futuro-blue);border-radius:50%;opacity:0.6;animation:orbFloat 6s ease-in-out infinite"></div>
        <div style="position:absolute;top:70%;left:12%;width:2px;height:2px;background:var(--warm-orange);border-radius:50%;opacity:0.5;animation:orbFloat 8s ease-in-out infinite alternate"></div>
        <div style="position:absolute;top:30%;right:10%;width:4px;height:4px;background:var(--futuro-purple);border-radius:50%;opacity:0.5;animation:orbFloat 7s ease-in-out infinite alternate-reverse"></div>
        <div style="position:absolute;top:80%;right:15%;width:2px;height:2px;background:var(--futuro-blue);border-radius:50%;opacity:0.4;animation:orbFloat 9s ease-in-out infinite"></div>
    </div>

    <div class="login-card animate-in">
        <!-- Logo -->
        <div class="login-logo">🏢</div>

        <!-- Titles -->
        <h1 class="login-title">Vivimostodos</h1>
        <p class="login-subtitle">
            <strong>¡Bienvenido de vuelta, vecino!</strong><br>
            <span style="font-size:0.78rem">Unidad Residencial — Portal de Gestión</span>
        </p>

        <!-- Error -->
        <?php if ($error): ?>
        <div class="alert alert-danger mb-3 animate-in">
            <i class="bi bi-exclamation-triangle-fill me-2"></i><?= sanitize($error) ?>
        </div>
        <?php endif; ?>

        <!-- Form -->
        <form method="POST" action="">
            <div class="mb-3">
                <label class="form-label">
                    <i class="bi bi-envelope me-1" style="color:var(--futuro-blue)"></i>
                    Correo electrónico
                </label>
                <input
                    type="email"
                    name="correo"
                    class="form-control"
                    placeholder="usuario@vivimostodos.com"
                    value="<?= sanitize($_POST['correo'] ?? '') ?>"
                    required
                    autocomplete="email"
                >
            </div>

            <div class="mb-4">
                <label class="form-label">
                    <i class="bi bi-lock me-1" style="color:var(--futuro-blue)"></i>
                    Contraseña
                </label>
                <div class="input-group">
                    <input
                        type="password"
                        name="password"
                        id="pwd-input"
                        class="form-control"
                        placeholder="••••••••"
                        required
                        autocomplete="current-password"
                    >
                    <button type="button" class="btn" onclick="togglePwd()" title="Mostrar/ocultar contraseña"
                        style="border:1px solid var(--border-glow);border-left:0;background:rgba(255,255,255,0.04);color:var(--text-muted)">
                        <i class="bi bi-eye" id="eye-icon"></i>
                    </button>
                </div>
            </div>

            <button type="submit" class="btn btn-primary w-100 py-2 fw-bold" style="font-size:0.95rem;letter-spacing:0.02em">
                <i class="bi bi-box-arrow-in-right me-2"></i>Iniciar Sesión
            </button>
        </form>

        <!-- Test credentials box -->
        <div class="login-test-box">
            <div style="color:var(--warm-orange);font-weight:700;margin-bottom:4px">⚡ Acceso de prueba</div>
            Admin: admin@vivimostodos.com / Admin123
        </div>
    </div>
</div>

<script>
function togglePwd() {
    const i = document.getElementById('pwd-input');
    const icon = document.getElementById('eye-icon');
    if (i.type === 'password') {
        i.type = 'text';
        icon.className = 'bi bi-eye-slash';
    } else {
        i.type = 'password';
        icon.className = 'bi bi-eye';
    }
}
</script>
</body>
</html>
