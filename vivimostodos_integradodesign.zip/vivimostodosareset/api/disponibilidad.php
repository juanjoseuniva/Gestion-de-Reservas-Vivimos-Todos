<?php
/**
 * api/disponibilidad.php
 * Endpoint AJAX — Verifica disponibilidad de fecha para reserva
 * Validaciones: 48h mínimo, 90 días máximo, sin doble reserva
 */
require_once 'C:\\xampp\\htdocs\\vivimostodos/config/session.php';
require_once 'C:\\xampp\\htdocs\\vivimostodos/config/database.php';
require_once 'C:\\xampp\\htdocs\\vivimostodos/config/functions.php';

header('Content-Type: application/json; charset=utf-8');

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['disponible' => false, 'mensaje' => 'No autorizado']);
    exit;
}

$fecha = trim($_GET['fecha'] ?? '');

// Validar formato de fecha
if (!$fecha || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $fecha) || !checkdate(
    (int)substr($fecha, 5, 2),
    (int)substr($fecha, 8, 2),
    (int)substr($fecha, 0, 4)
)) {
    echo json_encode(['disponible' => false, 'mensaje' => '❌ Formato de fecha inválido.']);
    exit;
}

// ── REGLA 1 + REGLA 2: 48h mínimo y 90d máximo ─────────────
$resultado = validarFechaReserva($fecha);
if (!$resultado['valida']) {
    $minima = (new DateTime('today'))->modify('+2 days');
    $evento = new DateTime($fecha);
    $codigo = $evento < $minima ? 'MIN_48H' : 'MAX_90D';
    echo json_encode([
        'disponible' => false,
        'codigo'     => $codigo,
        'mensaje'    => $resultado['mensaje'],
    ]);
    exit;
}

// ── REGLA 3: Sin doble reserva ────────────────────────────────
if (!fechaDisponible($fecha)) {
    echo json_encode([
        'disponible' => false,
        'codigo'     => 'FECHA_OCUPADA',
        'mensaje'    => '❌ Esta fecha ya tiene una reserva activa. El salón solo puede reservarse una vez por día.',
    ]);
    exit;
}

// ── TODO OK ───────────────────────────────────────────────────
echo json_encode([
    'disponible' => true,
    'codigo'     => 'OK',
    'mensaje'    => '✓ Fecha disponible para reservar.',
    'fecha'      => date('d/m/Y', strtotime($fecha)),
]);
