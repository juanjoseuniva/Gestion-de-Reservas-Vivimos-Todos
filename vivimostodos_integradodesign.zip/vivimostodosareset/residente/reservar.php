<?php
/**
 * residente/reservar.php
 */
require_once 'C:\\xampp\\htdocs\\vivimostodos/config/session.php';
require_once 'C:\\xampp\\htdocs\\vivimostodos/config/functions.php';
requireRole(['RESIDENTE']);

$db  = getDB();
$uid = currentUserId();
$pageTitle = 'Nueva Reserva';
$errors = [];

$fechaMinima = date('Y-m-d', strtotime('+2 days'));
$fechaMaxima = date('Y-m-d', strtotime('+90 days'));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fecha         = $_POST['fecha_evento']  ?? '';
    $observaciones = trim($_POST['observaciones'] ?? '');
    $insumos_ids   = $_POST['insumos']       ?? [];
    $cantidades    = $_POST['cantidades']    ?? [];

    if (!$fecha) {
        $errors[] = 'La fecha del evento es requerida.';
    } else {
        $validacion = validarFechaCompleta($fecha);
        if (!$validacion['valida']) {
            $errors[] = $validacion['mensaje'];
        }
    }

    if (empty($errors)) {
        $db->beginTransaction();
        try {
            $detallesPrep = [];
            $totalCosto   = 0;

            foreach ($insumos_ids as $key => $idInsumo) {
                $idInsumo = (int)$idInsumo;
                $cant     = (int)($cantidades[$key] ?? 0);
                if ($idInsumo <= 0 || $cant <= 0) continue;

                $ins = $db->prepare("SELECT * FROM inventario WHERE id_insumo=? AND estado='DISPONIBLE'");
                $ins->execute([$idInsumo]);
                $ins = $ins->fetch();

                if (!$ins) { $errors[] = "Insumo #{$idInsumo} no disponible."; continue; }
                if ($cant > $ins['cantidad_disponible']) {
                    $errors[] = "'{$ins['nombre']}': solicitadas $cant, disponibles {$ins['cantidad_disponible']}.";
                    continue;
                }

                $subtotal       = $cant * (float)$ins['precio_unitario'];
                $totalCosto    += $subtotal;
                $detallesPrep[] = ['id_insumo' => $idInsumo, 'cantidad' => $cant, 'subtotal' => $subtotal, 'nombre' => $ins['nombre']];
            }

            if (!empty($errors)) {
                $db->rollBack();
            } else {
                $db->prepare(
                    "INSERT INTO reservas (id_usuario, fecha_evento, hora_inicio, hora_fin, observaciones, estado)
                     VALUES (?, ?, '12:00:00', '23:59:00', ?, 'PENDIENTE')"
                )->execute([$uid, $fecha, $observaciones]);
                $idReserva = $db->lastInsertId();

                foreach ($detallesPrep as $det) {
                    $db->prepare("INSERT INTO detalle_reserva (id_reserva, id_insumo, cantidad, subtotal) VALUES (?, ?, ?, ?)")
                       ->execute([$idReserva, $det['id_insumo'], $det['cantidad'], $det['subtotal']]);
                }

                if ($totalCosto > 0) {
                    $db->prepare("INSERT INTO pagos (id_reserva, monto, estado) VALUES (?, ?, 'PENDIENTE')")
                       ->execute([$idReserva, $totalCosto]);
                }

                $user = currentUser();
                notificarAdmins("📅 Nueva reserva #{$idReserva} de {$user['nombre']} {$user['apellido']} para el " . formatFecha($fecha) . ($totalCosto > 0 ? " — Total: " . formatMoneda($totalCosto) : " — Sin costo"));
                crearNotificacion($uid, "📬 Tu solicitud de reserva #{$idReserva} para el " . formatFecha($fecha) . " fue enviada. El administrador la revisará pronto.");

                $db->commit();
                $msg = "✅ Reserva #{$idReserva} creada para el <strong>" . formatFecha($fecha) . "</strong>. Espera la aprobación del administrador.";
                if ($totalCosto > 0) $msg .= " Total a pagar si es aprobada: <strong>" . formatMoneda($totalCosto) . "</strong>.";
                flashMessage('success', $msg);
                redirect('/vivimostodos/residente/mis_reservas.php');
            }
        } catch (Exception $e) {
            $db->rollBack();
            $errors[] = 'Error al crear la reserva: ' . $e->getMessage();
        }
    }
}

$insumos = $db->query("SELECT * FROM inventario WHERE estado='DISPONIBLE' AND cantidad_disponible > 0 ORDER BY nombre")->fetchAll();
$reservasActivas = $db->query("SELECT DISTINCT fecha_evento FROM reservas WHERE estado IN ('PENDIENTE','APROBADA') AND fecha_evento >= CURDATE()")->fetchAll(PDO::FETCH_COLUMN);

include 'C:/xampp/htdocs/vivimostodos/includes/header.php';
include 'C:/xampp/htdocs/vivimostodos/includes/sidebar.php';
?>

<?= renderFlash() ?>

<div class="row justify-content-center">
    <div class="col-xl-9">

        <!-- Header -->
        <div class="d-flex align-items-center gap-3 mb-4 animate-in">
            <div style="width:48px;height:48px;background:var(--grad-primary);border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:1.4rem;box-shadow:var(--shadow-glow)">📅</div>
            <div>
                <div class="section-title">Solicitar Reserva</div>
                <div class="section-subtitle">Reserva el Salón Social para tu próximo evento 🎉</div>
            </div>
        </div>

        <!-- Reglas de negocio -->
        <div class="alert alert-info mb-4 animate-in delay-1" style="font-size:.84rem">
            <strong>📋 Reglas importantes:</strong>
            <div class="mt-2 d-flex flex-wrap gap-3" style="font-size:0.8rem">
                <span>⏱ Mínimo <strong>48h</strong> de anticipación (desde <?= formatFecha($fechaMinima) ?>)</span>
                <span>📆 Máximo <strong>90 días</strong> (hasta <?= formatFecha($fechaMaxima) ?>)</span>
                <span>🏛 Solo <strong>una reserva por día</strong></span>
                <span>⏳ Queda en <strong>PENDIENTE</strong> hasta aprobación</span>
            </div>
        </div>

        <?php if ($errors): ?>
        <div class="alert alert-danger animate-in">
            <strong><i class="bi bi-exclamation-circle me-1"></i>Corrige los siguientes errores:</strong>
            <ul class="mb-0 mt-2 ps-3">
                <?php foreach ($errors as $e): ?>
                <li><?= sanitize($e) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
        <?php endif; ?>

        <div class="card animate-in delay-1">
            <div class="card-header">
                <h5>📋 Datos de la Reserva</h5>
            </div>
            <div class="card-body">
                <form method="POST" id="form-reserva" novalidate>

                    <!-- Fecha y horas -->
                    <div class="row g-3 mb-4">
                        <div class="col-md-5">
                            <label class="form-label">
                                <i class="bi bi-calendar-event me-1" style="color:var(--futuro-blue)"></i>
                                Fecha del evento *
                            </label>
                            <input
                                type="date"
                                name="fecha_evento"
                                id="fecha-input"
                                class="form-control"
                                min="<?= $fechaMinima ?>"
                                max="<?= $fechaMaxima ?>"
                                value="<?= sanitize($_POST['fecha_evento'] ?? '') ?>"
                                required
                            >
                            <div id="msg-disponibilidad" class="mt-2" style="font-size:.82rem;display:none"></div>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Hora inicio</label>
                            <input type="time" class="form-control" value="12:00" readonly style="cursor:not-allowed;opacity:0.6">
                            <small style="color:var(--text-muted);font-size:0.73rem">Fijo: mediodía</small>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Hora fin</label>
                            <input type="time" class="form-control" value="23:59" readonly style="cursor:not-allowed;opacity:0.6">
                            <small style="color:var(--text-muted);font-size:0.73rem">Fijo: medianoche</small>
                        </div>
                    </div>

                    <!-- Descripción -->
                    <div class="mb-4">
                        <label class="form-label">
                            <i class="bi bi-chat-text me-1" style="color:var(--warm-orange)"></i>
                            Descripción del evento
                            <small style="color:var(--text-muted);font-weight:400">(opcional)</small>
                        </label>
                        <textarea
                            name="observaciones"
                            class="form-control"
                            rows="2"
                            placeholder="Tipo de evento, número aproximado de invitados, requerimientos especiales…"
                        ><?= sanitize($_POST['observaciones'] ?? '') ?></textarea>
                    </div>

                    <!-- Insumos -->
                    <?php if ($insumos): ?>
                    <hr>
                    <div class="d-flex align-items-center gap-2 mb-3">
                        <div style="width:32px;height:32px;background:rgba(255,140,66,0.15);border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:1rem">📦</div>
                        <div>
                            <div style="font-weight:700;font-size:0.9rem;color:var(--text-primary)">Insumos del Salón</div>
                            <div style="font-size:0.73rem;color:var(--text-muted)">Selecciona lo que necesitas para tu evento (opcional)</div>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-sm" id="tabla-insumos">
                            <thead>
                                <tr>
                                    <th style="width:44px">Sel.</th>
                                    <th>Insumo</th>
                                    <th>Disponible</th>
                                    <th>Precio/U</th>
                                    <th style="width:110px">Cantidad</th>
                                    <th>Subtotal</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($insumos as $idx => $ins): ?>
                            <tr class="insumo-row" id="row-<?= $idx ?>">
                                <td>
                                    <input type="checkbox" class="form-check-input chk-insumo"
                                        data-idx="<?= $idx ?>"
                                        data-precio="<?= $ins['precio_unitario'] ?>"
                                        data-max="<?= $ins['cantidad_disponible'] ?>"
                                        onchange="toggleInsumo(this)">
                                    <input type="hidden" name="insumos[]" id="hid-id-<?= $idx ?>" value="">
                                </td>
                                <td>
                                    <strong style="color:var(--text-primary)"><?= sanitize($ins['nombre']) ?></strong>
                                    <?php if ($ins['descripcion']): ?>
                                    <br><small style="color:var(--text-muted)"><?= sanitize($ins['descripcion']) ?></small>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span style="font-weight:700;color:<?= $ins['cantidad_disponible'] < 5 ? 'var(--accent-danger)' : 'var(--accent-success)' ?>">
                                        <?= $ins['cantidad_disponible'] ?>
                                    </span>
                                </td>
                                <td>
                                    <?= $ins['precio_unitario'] > 0
                                        ? '<span style="color:var(--futuro-blue);font-weight:600">' . formatMoneda((float)$ins['precio_unitario']) . '</span>'
                                        : '<span class="badge badge-aprobada">Gratis</span>' ?>
                                </td>
                                <td>
                                    <input type="number" name="cantidades[]"
                                        id="cant-<?= $idx ?>" class="form-control form-control-sm"
                                        min="1" max="<?= $ins['cantidad_disponible'] ?>"
                                        value="0" disabled
                                        oninput="calcSubtotal(<?= $idx ?>, <?= $ins['precio_unitario'] ?>)"
                                        style="width:90px">
                                    <input type="hidden" id="real-id-<?= $idx ?>" value="<?= $ins['id_insumo'] ?>">
                                </td>
                                <td id="sub-<?= $idx ?>" style="font-family:var(--font-mono);font-weight:600;color:var(--text-secondary)">
                                    —
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="5" class="text-end fw-bold" style="color:var(--text-secondary)">TOTAL INSUMOS:</td>
                                    <td id="total-insumos" style="font-family:var(--font-mono);font-weight:800;color:var(--futuro-blue)">$0</td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                    <?php else: ?>
                    <div class="alert alert-warning">No hay insumos disponibles en este momento.</div>
                    <?php endif; ?>

                    <!-- Submit -->
                    <div class="d-flex gap-3 mt-4 pt-3 border-top align-items-center flex-wrap">
                        <button type="submit" class="btn btn-primary px-4" id="btn-enviar" disabled>
                            <i class="bi bi-send me-2"></i>Enviar Solicitud de Reserva
                        </button>
                        <a href="mis_reservas.php" class="btn btn-outline-secondary">Cancelar</a>
                        <span id="msg-btn" style="font-size:.8rem;color:var(--text-muted)">
                            Selecciona una fecha válida para continuar
                        </span>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php
$fechasOcupadas = json_encode($reservasActivas);
$extraJs = "<script>
const fechasOcupadas = $fechasOcupadas;
const subtotales = {};

const inputFecha = document.getElementById('fecha-input');
const msgDisp    = document.getElementById('msg-disponibilidad');
const btnEnviar  = document.getElementById('btn-enviar');
const msgBtn     = document.getElementById('msg-btn');

inputFecha.addEventListener('change', async () => {
    const fecha = inputFecha.value;
    if (!fecha) return resetFecha();

    msgDisp.style.display = 'block';
    msgDisp.style.color = 'var(--text-muted)';
    msgDisp.textContent = '⏳ Verificando disponibilidad...';

    try {
        const res  = await fetch('/vivimostodos/api/disponibilidad.php?fecha=' + fecha);
        const data = await res.json();

        if (data.disponible) {
            msgDisp.style.color = 'var(--accent-success)';
            msgDisp.textContent = data.mensaje;
            btnEnviar.disabled = false;
            msgBtn.textContent = '';
        } else {
            msgDisp.style.color = 'var(--accent-danger)';
            msgDisp.textContent = data.mensaje;
            btnEnviar.disabled = true;
            msgBtn.textContent = 'Elige otra fecha para continuar';
            if (data.codigo !== 'MIN_48H' && data.codigo !== 'MAX_90D') {
                inputFecha.value = '';
            }
        }
    } catch(e) {
        msgDisp.style.color = 'var(--accent-warning)';
        msgDisp.textContent = '⚠️ Error verificando disponibilidad. Intenta de nuevo.';
        btnEnviar.disabled = true;
    }
});

function resetFecha() {
    msgDisp.style.display = 'none';
    btnEnviar.disabled = true;
    msgBtn.textContent = 'Selecciona una fecha válida para continuar';
}

function toggleInsumo(cb) {
    const idx    = cb.dataset.idx;
    const cantEl = document.getElementById('cant-' + idx);
    const hidEl  = document.getElementById('hid-id-' + idx);
    const realId = document.getElementById('real-id-' + idx).value;
    const row    = document.getElementById('row-' + idx);

    if (cb.checked) {
        cantEl.disabled = false;
        cantEl.value    = 1;
        hidEl.value     = realId;
        row.classList.add('selected');
        calcSubtotal(idx, cb.dataset.precio);
    } else {
        cantEl.disabled = true;
        cantEl.value    = 0;
        hidEl.value     = '';
        row.classList.remove('selected');
        subtotales[idx] = 0;
        document.getElementById('sub-' + idx).textContent = '—';
        actualizarTotal();
    }
}

function calcSubtotal(idx, precio) {
    const cant = parseInt(document.getElementById('cant-' + idx).value) || 0;
    const sub  = cant * parseFloat(precio);
    subtotales[idx] = sub;
    document.getElementById('sub-' + idx).textContent =
        precio > 0 ? '\$' + sub.toLocaleString('es-CO') : 'Gratis';
    actualizarTotal();
}

function actualizarTotal() {
    const sum = Object.values(subtotales).reduce((a,b) => a+b, 0);
    document.getElementById('total-insumos').textContent = '\$' + sum.toLocaleString('es-CO');
}
</script>";
include 'C:/xampp/htdocs/vivimostodos/includes/footer.php'; ?>
