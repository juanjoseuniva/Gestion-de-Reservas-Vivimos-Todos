<?php
/**
 * residente/mis_reservas.php
 */
require_once 'C:\\xampp\\htdocs\\vivimostodos/config/session.php';
require_once 'C:\\xampp\\htdocs\\vivimostodos/config/functions.php';
requireRole(['RESIDENTE']);

$db  = getDB();
$uid = currentUserId();
$pageTitle = 'Mis Reservas';

$reservas = $db->prepare(
    "SELECT r.*,
            COALESCE(p.estado, 'SIN PAGO') as estado_pago,
            COALESCE(p.monto, 0)            as monto_pago,
            p.id_pago
     FROM reservas r
     LEFT JOIN pagos p ON p.id_reserva = r.id_reserva
     WHERE r.id_usuario = ?
     ORDER BY r.fecha_evento DESC"
);
$reservas->execute([$uid]);
$misReservas = $reservas->fetchAll();

$stats = ['PENDIENTE'=>0,'APROBADA'=>0,'RECHAZADA'=>0,'CANCELADA'=>0];
foreach ($misReservas as $r) $stats[$r['estado']] = ($stats[$r['estado']] ?? 0) + 1;

include 'C:/xampp/htdocs/vivimostodos/includes/header.php';
include 'C:/xampp/htdocs/vivimostodos/includes/sidebar.php';
?>

<?= renderFlash() ?>

<!-- Header row -->
<div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-3 animate-in">
    <div>
        <div class="section-title">Mis Reservas</div>
        <div class="section-subtitle">Historial y estado de tus solicitudes del salón 🏛</div>
    </div>
    <a href="reservar.php" class="btn btn-primary">
        <i class="bi bi-plus-lg me-2"></i>Nueva Reserva
    </a>
</div>

<!-- Mini stats -->
<div class="d-flex gap-2 flex-wrap mb-4 animate-in delay-1">
    <span class="mini-stat pendiente">⏳ Pendientes: <strong><?= $stats['PENDIENTE'] ?></strong></span>
    <span class="mini-stat aprobada">✅ Aprobadas: <strong><?= $stats['APROBADA'] ?></strong></span>
    <span class="mini-stat rechazada">❌ Rechazadas: <strong><?= $stats['RECHAZADA'] ?></strong></span>
    <?php if ($stats['CANCELADA'] > 0): ?>
    <span class="mini-stat" style="background:rgba(160,160,192,0.08);color:var(--text-muted);border-color:rgba(160,160,192,0.2)">🚫 Canceladas: <strong><?= $stats['CANCELADA'] ?></strong></span>
    <?php endif; ?>
</div>

<?php if (empty($misReservas)): ?>
<!-- Empty state -->
<div class="card animate-in delay-2">
    <div class="card-body text-center py-5">
        <div style="font-size:4rem;margin-bottom:16px;opacity:0.6">📅</div>
        <h5 style="color:var(--text-primary);font-family:var(--font-display)">Aún no tienes reservas</h5>
        <p style="color:var(--text-muted);margin-bottom:24px">¡Reserva el salón social para tu próximo evento familiar!</p>
        <a href="reservar.php" class="btn btn-primary px-4">
            <i class="bi bi-plus-lg me-2"></i>Hacer mi primera reserva
        </a>
    </div>
</div>

<?php else: ?>
<div class="row g-3">
<?php foreach ($misReservas as $idx => $r):
    $estadoLower = strtolower($r['estado']);
    $esHoy    = $r['fecha_evento'] === date('Y-m-d');
    $esFutura = $r['fecha_evento'] >= date('Y-m-d');
    $semaforo = colorSemaforo($r['fecha_evento']);

    $borderClass = 'border-' . $estadoLower;

    $badgeInfo = [
        'pendiente' => ['⏳', 'badge-pendiente'],
        'aprobada'  => ['✅', 'badge-aprobada'],
        'rechazada' => ['❌', 'badge-rechazada'],
        'cancelada' => ['🚫', 'badge-cancelada'],
    ];
    [$bIcon, $bClass] = $badgeInfo[$estadoLower] ?? ['•', 'badge-cancelada'];
?>
<div class="col-lg-6 animate-in" style="animation-delay:<?= 0.05 * ($idx % 4) ?>s">
    <div class="reserva-card <?= $borderClass ?>">
        <div class="card-body">

            <!-- Header -->
            <div class="d-flex justify-content-between align-items-start mb-3">
                <div>
                    <div style="font-family:var(--font-mono);font-size:0.7rem;color:var(--text-muted);margin-bottom:4px">
                        #<?= $r['id_reserva'] ?>
                    </div>
                    <div style="font-family:var(--font-display);font-size:1.1rem;font-weight:700;color:var(--text-primary)">
                        <?= formatFecha($r['fecha_evento']) ?>
                    </div>
                    <div style="font-size:0.78rem;color:var(--text-muted);margin-top:2px">
                        🕐 12:00 — 23:59
                        <?php if ($esHoy): ?>
                        <span class="badge badge-pendiente ms-1" style="font-size:0.6rem">HOY</span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="text-end d-flex flex-column gap-1">
                    <span class="badge <?= $bClass ?>"><?= $bIcon ?> <?= $r['estado'] ?></span>
                    <span style="font-size:0.72rem;color:var(--text-muted)"><?= $semaforo['icon'] ?> <?= $semaforo['label'] ?></span>
                </div>
            </div>

            <!-- Observaciones -->
            <?php if ($r['observaciones'] && $r['estado'] !== 'RECHAZADA'): ?>
            <p style="font-size:0.8rem;color:var(--text-muted);margin-bottom:10px;border-left:2px solid var(--border-glow);padding-left:10px">
                <?= sanitize(substr($r['observaciones'], 0, 100)) ?><?= strlen($r['observaciones']) > 100 ? '…' : '' ?>
            </p>
            <?php endif; ?>

            <!-- Motivo rechazo -->
            <?php if ($r['estado'] === 'RECHAZADA' && $r['observaciones']): ?>
            <div class="alert alert-danger py-2 mb-3" style="font-size:0.8rem">
                <i class="bi bi-x-circle me-1"></i><?= sanitize($r['observaciones']) ?>
            </div>
            <?php endif; ?>

            <!-- Pago -->
            <div class="d-flex align-items-center gap-2 mb-3" style="font-size:0.78rem">
                <span style="color:var(--text-muted)">💳 Pago:</span>
                <?php
                $pClass = badgePago($r['estado_pago']);
                $pagoBadgeMap = [
                    'VALIDADO'  => 'badge-aprobada',
                    'PENDIENTE' => 'badge-pendiente',
                    'RECHAZADO' => 'badge-rechazada',
                    'SIN PAGO'  => 'badge-cancelada',
                ];
                $pagoBadge = $pagoBadgeMap[$r['estado_pago']] ?? 'badge-cancelada';
                ?>
                <span class="badge <?= $pagoBadge ?>"><?= $r['estado_pago'] ?></span>
                <?php if ($r['monto_pago'] > 0): ?>
                <span style="font-family:var(--font-mono);font-weight:700;color:var(--futuro-blue)">
                    <?= formatMoneda((float)$r['monto_pago']) ?>
                </span>
                <?php endif; ?>
            </div>

            <!-- Acciones -->
            <div class="d-flex gap-2 flex-wrap">
                <a href="detalle_reserva.php?id=<?= $r['id_reserva'] ?>"
                   class="btn btn-sm btn-outline-secondary">
                   <i class="bi bi-eye me-1"></i>Ver detalle
                </a>

                <?php if ($r['estado'] === 'APROBADA'
                    && in_array($r['estado_pago'], ['SIN PAGO', 'RECHAZADO'])
                    && (float)$r['monto_pago'] > 0): ?>
                <a href="pagar.php?id=<?= $r['id_reserva'] ?>"
                   class="btn btn-sm btn-warm">
                   <i class="bi bi-credit-card me-1"></i>Subir Comprobante
                </a>
                <?php endif; ?>

                <?php if (in_array($r['estado'], ['PENDIENTE','APROBADA']) && $esFutura): ?>
                <form method="POST" action="cancelar.php" class="d-inline">
                    <input type="hidden" name="id" value="<?= $r['id_reserva'] ?>">
                    <button type="submit" class="btn btn-sm btn-outline-danger"
                        onclick="return confirm('¿Cancelar la reserva del <?= formatFecha($r['fecha_evento']) ?>? Esta acción no se puede deshacer.')">
                        <i class="bi bi-trash3 me-1"></i>Cancelar
                    </button>
                </form>
                <?php endif; ?>
            </div>
        </div>

        <div class="card-footer">
            Solicitada: <?= date('d/m/Y H:i', strtotime($r['fecha_solicitud'])) ?>
        </div>
    </div>
</div>
<?php endforeach; ?>
</div>
<?php endif; ?>

<?php include 'C:/xampp/htdocs/vivimostodos/includes/footer.php'; ?>
